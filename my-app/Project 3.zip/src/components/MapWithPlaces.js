import React, { useState, useEffect, useCallback } from 'react';
import { GoogleMap, Marker, useLoadScript } from '@react-google-maps/api';

const mapContainerStyle = { width: '100%', height: '400px' };
const defaultCenter = { lat: 40.7128, lng: -74.0060 };

export default function MapWithPlaces({ userLocation, specialty }) {
  const [places, setPlaces] = useState([]);
  
  const { isLoaded, loadError } = useLoadScript({
    googleMapsApiKey: process.env.REACT_APP_GOOGLE_MAPS_API_KEY,
    libraries: ['places']
  });

  const fetchNearby = useCallback((map) => {
    if (!userLocation || !map || !specialty) return;
    const service = new window.google.maps.places.PlacesService(map);
    service.nearbySearch({
      location: userLocation,
      radius: 5000,                    // 5 km radius
      keyword: specialty + ' clinic', // e.g. "orthopedic clinic"
      type: ['hospital','doctor','clinic']
    }, (results, status) => {
      if (status === window.google.maps.places.PlacesServiceStatus.OK) {
        setPlaces(results.slice(0, 10)); // top 10 matches
      }
    });
  }, [userLocation, specialty]);

  if (loadError) return <div>Error loading maps</div>;
  if (!isLoaded) return <div>Loading map…</div>;

  const center = userLocation || defaultCenter;

  return (
    <GoogleMap
      mapContainerStyle={mapContainerStyle}
      zoom={13}
      center={center}
      onLoad={fetchNearby}
    >
      {userLocation && (
        <Marker
          position={userLocation}
          icon={{
            url: '/user-location-icon.svg',
            scaledSize: { width: 30, height: 30 }
          }}
        />
      )}
      {places.map(place => (
        <Marker
          key={place.place_id}
          position={place.geometry.location}
          title={place.name}
          onClick={() => {
            const dest = `${place.geometry.location.lat()},${place.geometry.location.lng()}`;
            window.open(
              `https://www.google.com/maps/dir/?api=1&origin=${center.lat},${center.lng}&destination=${dest}&travelmode=driving`,
              '_blank'
            );
          }}
        />
      ))}
    </GoogleMap>
  );
}
