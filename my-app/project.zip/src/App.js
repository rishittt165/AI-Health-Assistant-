// import React, { useState, useEffect } from 'react';
// import './App.css';
// import { analyzeSymptoms } from './utils/gemini';
// import useSpeechRecognition from './hooks/useSpeechRecognition';

// function App() {
//   const [isListening, setIsListening] = useState(false);
//   const [transcript, setTranscript] = useState("");
//   const [aiResponse, setAiResponse] = useState(null);
//   const [hospitals, setHospitals] = useState([]);
//   const [isProcessing, setIsProcessing] = useState(false);
//   const [userLocation, setUserLocation] = useState(null);
//   const [apiKey, setApiKey] = useState('AIzaSyDIPhpvk8Rky9_29epiSQX73aJfQpLtImk'); // You'll set this in environment variables

//   // Get user location
//   useEffect(() => {
//     if (navigator.geolocation) {
//       navigator.geolocation.getCurrentPosition(
//         (position) => {
//           setUserLocation({
//             lat: position.coords.latitude,
//             lng: position.coords.longitude
//           });
//         },
//         (error) => {
//           console.error("Geolocation error:", error);
//           // Default to New York coordinates if geolocation fails
//           setUserLocation({ lat: 40.7128, lng: -74.0060 });
//         }
//       );
//     }
//   }, []);

//   const { startListening, stopListening } = useSpeechRecognition({
//     onResult: (result) => setTranscript(result),
//     onEnd: () => {
//       setIsListening(false);
//       if (transcript) processSymptoms(transcript);
//     }
//   });

//   const handleMicClick = () => {
//     if (isListening) {
//       stopListening();
//       setIsListening(false);
//     } else {
//       setTranscript("");
//       setIsListening(true);
//       startListening();
//     }
//   };

//   const processSymptoms = async (symptoms) => {
//     if (!symptoms.trim()) return;
    
//     setIsProcessing(true);
//     try {
//       const response = await analyzeSymptoms(symptoms);
//       setAiResponse(response);
//       findNearbyHospitals(response.suggestedSpecialty);
//     } catch (error) {
//       console.error("Error processing symptoms:", error);
//       alert("Error analyzing symptoms. Please try again.");
//     }
//     setIsProcessing(false);
//   };

//   const findNearbyHospitals = async (specialty) => {
//     if (!userLocation) return;

//     // This is a mock implementation - in real app, use Google Places API
//     const mockHospitals = [
//       {
//         id: 1,
//         name: "City General Hospital",
//         address: "123 Medical Center Drive",
//         distance: "0.8 miles",
//         specialty: "Emergency Medicine",
//         rating: 4.5,
//         waitTime: "15 min",
//         coordinates: { lat: userLocation.lat + 0.01, lng: userLocation.lng + 0.01 }
//       },
//       {
//         id: 2,
//         name: "Unity Medical Center",
//         address: "456 Health Avenue",
//         distance: "1.2 miles",
//         specialty: "General Practice",
//         rating: 4.2,
//         waitTime: "25 min",
//         coordinates: { lat: userLocation.lat - 0.01, lng: userLocation.lng + 0.02 }
//       },
//       {
//         id: 3,
//         name: "Advanced Care Institute",
//         address: "789 Wellness Boulevard",
//         distance: "2.1 miles",
//         specialty: "Orthopedics",
//         rating: 4.7,
//         waitTime: "10 min",
//         coordinates: { lat: userLocation.lat + 0.02, lng: userLocation.lng - 0.01 }
//       }
//     ];

//     // Filter by specialty if provided
//     const filteredHospitals = specialty && specialty !== "General Practice" 
//       ? mockHospitals.filter(hospital => hospital.specialty === specialty)
//       : mockHospitals;

//     setHospitals(filteredHospitals);
//   };

//   const getDirections = (hospital) => {
//     if (!userLocation || !hospital.coordinates) return;
    
//     const url = `https://www.google.com/maps/dir/?api=1&origin=${userLocation.lat},${userLocation.lng}&destination=${hospital.coordinates.lat},${hospital.coordinates.lng}&travelmode=driving`;
//     window.open(url, '_blank');
//   };

//   return (
//     <div className="health-assistant">
//       <header className="app-header">
//         <div className="app-title">
//           <i className="fas fa-heartbeat"></i> Health Assistant
//         </div>
//         <div className="user-info">
//           <i className="fas fa-map-marker-alt"></i>
//           <span>{userLocation ? "Location enabled" : "Enable location"}</span>
//         </div>
//       </header>
      
//       <div className="app-content">
//         <div className="sidebar">
//           <h3>How it works</h3>
//           <ol style={{marginLeft: '20px', marginTop: '15px', lineHeight: '1.8'}}>
//             <li>Click the microphone button</li>
//             <li>Describe your symptoms</li>
//             <li>AI will analyze your condition</li>
//             <li>Get personalized health advice</li>
//             <li>Find the best hospitals nearby</li>
//           </ol>
          
//           <div style={{marginTop: '30px'}}>
//             <h3>Try saying:</h3>
//             <ul style={{marginLeft: '20px', marginTop: '10px', lineHeight: '1.8'}}>
//               <li>"I have a headache and fever"</li>
//               <li>"My stomach hurts"</li>
//               <li>"I have chest pain"</li>
//               <li>"My back has been hurting"</li>
//             </ul>
//           </div>
//         </div>
        
//         <div className="main-content">
//           <div className="speech-section">
//             <h2>Describe your symptoms</h2>
//             <button 
//               className={`mic-button ${isListening ? 'listening' : ''}`}
//               onClick={handleMicClick}
//             >
//               <i className="fas fa-microphone"></i>
//             </button>
//             <p>{isListening ? "Listening... Speak now" : "Click the microphone to start"}</p>
            
//             <div className="transcript-box">
//               {transcript || (isListening ? "Listening..." : "Your speech will appear here...")}
//             </div>
//           </div>
          
//           {isProcessing && (
//             <div style={{textAlign: 'center', margin: '20px 0'}}>
//               <i className="fas fa-spinner fa-spin" style={{fontSize: '24px', color: '#3498db'}}></i>
//               <p>Analyzing your symptoms with AI...</p>
//             </div>
//           )}
          
//           {aiResponse && (
//             <div className="response-section">
//               <h2>Health Assessment</h2>
//               <div style={{marginTop: '15px'}}>
//                 <p><strong>Condition:</strong> {aiResponse.diagnosis}</p>
//                 <p><strong>Severity:</strong> <span style={{color: aiResponse.severity === 'high' ? '#e74c3c' : aiResponse.severity === 'medium' ? '#f39c12' : '#27ae60'}}>
//                   {aiResponse.severity}
//                 </span></p>
//                 <p><strong>Description:</strong> {aiResponse.description}</p>
//                 <p><strong>Advice:</strong> {aiResponse.advice}</p>
//               </div>
//             </div>
//           )}
          
//           {hospitals.length > 0 && (
//             <div className="hospitals-section">
//               <h2 className="section-title">Recommended Hospitals Nearby</h2>
//               <p>Based on your symptoms, we recommend these facilities:</p>
              
//               {hospitals.map(hospital => (
//                 <div key={hospital.id} className="hospital-card">
//                   <div className="hospital-icon">
//                     <i className="fas fa-hospital"></i>
//                   </div>
//                   <div className="hospital-info">
//                     <div className="hospital-name">{hospital.name}</div>
//                     <div className="hospital-address">{hospital.address}</div>
//                     <div className="hospital-distance">
//                       {hospital.distance} away • {hospital.specialty} • Wait time: {hospital.waitTime}
//                     </div>
//                   </div>
//                   <button 
//                     className="action-button"
//                     onClick={() => getDirections(hospital)}
//                   >
//                     Directions <i className="fas fa-directions"></i>
//                   </button>
//                 </div>
//               ))}
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// }

// export default App;


import React, { useState, useEffect } from 'react';
import './App.css';
import { analyzeSymptoms } from './utils/gemini'; // Make sure this path is correct
import useSpeechRecognition from './hooks/useSpeechRecognition';

function App() {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [aiResponse, setAiResponse] = useState(null);
  const [hospitals, setHospitals] = useState([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [userLocation, setUserLocation] = useState(null);
  // REMOVED: const [apiKey, setApiKey] = useState('AIzaSyDIPhpvk8Rky9_29epiSQX73aJfQpLtImk');


  // Get user location
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => {
          console.error("Geolocation error:", error);
          setUserLocation({ lat: 40.7128, lng: -74.0060 }); // Default to New York
        }
      );
    }

    // --- NEW: Call analyzeSymptoms with the hardcoded input for testing ---
    const testGeminiCall = async () => {
      console.log("Initiating hardcoded Gemini API call for diabetes symptoms...");
      const result = await analyzeSymptoms("This parameter is ignored due to hardcoded prompt in gemini.js");
      // The actual logging happens inside analyzeSymptoms, but you could also log it here:
      // console.log("Result from hardcoded Gemini call in App.js:", result);
    };

    testGeminiCall(); // Execute the test call when component mounts

  }, []); // Empty dependency array means this runs once on mount


  const { startListening, stopListening } = useSpeechRecognition({
    onResult: (result) => setTranscript(result),
    onEnd: () => {
      setIsListening(false);
      if (transcript) processSymptoms(transcript);
    }
  });

  const handleMicClick = () => {
    if (isListening) {
      stopListening();
      setIsListening(false);
    } else {
      setTranscript("");
      setIsListening(true);
      startListening();
    }
  };

  const processSymptoms = async (symptoms) => {
    if (!symptoms.trim()) return;

    setIsProcessing(true);
    try {
      // This call will *still* use the hardcoded prompt in gemini.js for now.
      const response = await analyzeSymptoms(symptoms);
      setAiResponse(response);
      findNearbyHospitals(response.suggestedSpecialty);
    } catch (error) {
      console.error("Error processing symptoms:", error);
      alert("Error analyzing symptoms. Please try again.");
    }
    setIsProcessing(false);
  };

  const findNearbyHospitals = async (specialty) => {
    if (!userLocation) return;

    const mockHospitals = [
      // ... (your mock hospitals remain the same)
      {
        id: 1,
        name: "City General Hospital",
        address: "123 Medical Center Drive",
        distance: "0.8 miles",
        specialty: "Emergency Medicine",
        rating: 4.5,
        waitTime: "15 min",
        coordinates: { lat: userLocation.lat + 0.01, lng: userLocation.lng + 0.01 }
      },
      {
        id: 2,
        name: "Unity Medical Center",
        address: "456 Health Avenue",
        distance: "1.2 miles",
        specialty: "General Practice",
        rating: 4.2,
        waitTime: "25 min",
        coordinates: { lat: userLocation.lat - 0.01, lng: userLocation.lng + 0.02 }
      },
      {
        id: 3,
        name: "Advanced Care Institute",
        address: "789 Wellness Boulevard",
        distance: "2.1 miles",
        specialty: "Orthopedics",
        rating: 4.7,
        waitTime: "10 min",
        coordinates: { lat: userLocation.lat + 0.02, lng: userLocation.lng - 0.01 }
      }
    ];

    const filteredHospitals = specialty && specialty !== "General Practice"
      ? mockHospitals.filter(hospital => hospital.specialty === specialty)
      : mockHospitals;

    setHospitals(filteredHospitals);
  };

  const getDirections = (hospital) => {
    if (!userLocation || !hospital.coordinates) return;

    const url = `https://www.google.com/maps/dir/?api=1&origin=${userLocation.lat},${userLocation.lng}&destination=${hospital.coordinates.lat},${hospital.coordinates.lng}&travelmode=driving`;
    window.open(url, '_blank');
  };

  return (
    <div className="health-assistant">
      <header className="app-header">
        <div className="app-title">
          <i className="fas fa-heartbeat"></i> Health Assistant
        </div>
        <div className="user-info">
          <i className="fas fa-map-marker-alt"></i>
          <span>{userLocation ? "Location enabled" : "Enable location"}</span>
        </div>
      </header>

      <div className="app-content">
        <div className="sidebar">
          <h3>How it works</h3>
          <ol style={{ marginLeft: '20px', marginTop: '15px', lineHeight: '1.8' }}>
            <li>Click the microphone button</li>
            <li>Describe your symptoms</li>
            <li>AI will analyze your condition</li>
            <li>Get personalized health advice</li>
            <li>Find the best hospitals nearby</li>
          </ol>

          <div style={{ marginTop: '30px' }}>
            <h3>Try saying:</h3>
            <ul style={{ marginLeft: '20px', marginTop: '10px', lineHeight: '1.8' }}>
              <li>"I have a headache and fever"</li>
              <li>"My stomach hurts"</li>
              <li>"I have chest pain"</li>
              <li>"My back has been hurting"</li>
            </ul>
          </div>
        </div>

        <div className="main-content">
          <div className="speech-section">
            <h2>Describe your symptoms</h2>
            <button
              className={`mic-button ${isListening ? 'listening' : ''}`}
              onClick={handleMicClick}
            >
              <i className="fas fa-microphone"></i>
            </button>
            <p>{isListening ? "Listening... Speak now" : "Click the microphone to start"}</p>

            <div className="transcript-box">
              {transcript || (isListening ? "Listening..." : "Your speech will appear here...")}
            </div>
          </div>

          {isProcessing && (
            <div style={{ textAlign: 'center', margin: '20px 0' }}>
              <i className="fas fa-spinner fa-spin" style={{ fontSize: '24px', color: '#3498db' }}></i>
              <p>Analyzing your symptoms with AI...</p>
            </div>
          )}

          {aiResponse && (
            <div className="response-section">
              <h2>Health Assessment</h2>
              <div style={{ marginTop: '15px' }}>
                <p><strong>Condition:</strong> {aiResponse.diagnosis}</p>
                <p><strong>Severity:</strong> <span style={{ color: aiResponse.severity === 'high' ? '#e74c3c' : aiResponse.severity === 'medium' ? '#f39c12' : '#27ae60' }}>
                  {aiResponse.severity}
                </span></p>
                <p><strong>Description:</strong> {aiResponse.description}</p>
                <p><strong>Advice:</strong> {aiResponse.advice}</p>
                {/* Display symptoms_list if available */}
                {aiResponse.symptoms_list && aiResponse.symptoms_list.length > 0 && (
                  <div>
                    <p><strong>Key Symptoms:</strong></p>
                    <ul>
                      {aiResponse.symptoms_list.map((symptom, index) => (
                        <li key={index}>{symptom}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          )}

          {hospitals.length > 0 && (
            <div className="hospitals-section">
              <h2 className="section-title">Recommended Hospitals Nearby</h2>
              <p>Based on your symptoms, we recommend these facilities:</p>

              {hospitals.map(hospital => (
                <div key={hospital.id} className="hospital-card">
                  <div className="hospital-icon">
                    <i className="fas fa-hospital"></i>
                  </div>
                  <div className="hospital-info">
                    <div className="hospital-name">{hospital.name}</div>
                    <div className="hospital-address">{hospital.address}</div>
                    <div className="hospital-distance">
                      {hospital.distance} away • {hospital.specialty} • Wait time: {hospital.waitTime}
                    </div>
                  </div>
                  <button
                    className="action-button"
                    onClick={() => getDirections(hospital)}
                  >
                    Directions <i className="fas fa-directions"></i>
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;