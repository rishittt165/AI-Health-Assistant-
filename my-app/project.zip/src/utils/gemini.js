// import { GoogleGenerativeAI } from "@google/generative-ai";

// // Replace with your actual API key
// const genAI = new GoogleGenerativeAI('AIzaSyDIPhpvk8Rky9_29epiSQX73aJfQpLtImk');

// export const analyzeSymptoms = async (symptoms) => {
//   try {
//     // Use the correct model name - gemini-1.0-pro or gemini-pro
//     const model = genAI.getGenerativeModel({ 
//       model: "gemini-1.0-pro",
//       // Alternatively, you can try these model names:
//       // model: "gemini-pro", 
//       // model: "models/gemini-pro",
//     });
    
//     const prompt = `Analyze these medical symptoms and provide a structured JSON response: "${symptoms}"
    
//     Return ONLY JSON in this exact format:
//     {
//       "diagnosis": "likely condition",
//       "severity": "low/medium/high",
//       "description": "brief explanation",
//       "advice": "recommended actions",
//       "suggestedSpecialty": "medical specialty needed"
//     }`;

//     const result = await model.generateContent(prompt);
//     const response = result.response;
//     const text = response.text();
    
//     // Extract JSON from the response
//     const jsonMatch = text.match(/\{[\s\S]*\}/);
//     if (jsonMatch) {
//       return JSON.parse(jsonMatch[0]);
//     }
    
//     throw new Error("Invalid response format from AI");
//   } catch (error) {
//     console.error("Gemini API Error:", error);
    
//     // Fallback mock response if API fails
//     return {
//       diagnosis: "General Medical Consultation Needed",
//       severity: "medium",
//       description: "Please consult with a healthcare professional for proper diagnosis",
//       advice: "Schedule an appointment with your doctor for evaluation",
//       suggestedSpecialty: "General Practice"
//     };
//   }
// };


import { GoogleGenerativeAI } from "@google/generative-ai";

// Replace with your actual API key
// IMPORTANT: For production, use environment variables as discussed earlier.
// For this hardcoded test, it's fine temporarily.
const genAI = new GoogleGenerativeAI('AIzaSyDIPhpvk8Rky9_29epiSQX73aJfQpLtImk');

export const analyzeSymptoms = async (symptoms) => { // This function still accepts 'symptoms'
  try {
    const model = genAI.getGenerativeModel({
      model: "gemini-2.0-flash",
    });

    // The prompt now includes the specific request for diabetes symptoms
    // We're overriding the 'symptoms' parameter for this specific test
    const hardcodedPrompt = `Give me 5 symptoms for diabetes. Provide the answer in the following JSON format:
    {
      "diagnosis": "likely condition",
      "severity": "low/medium/high",
      "description": "brief explanation",
      "advice": "recommended actions",
      "suggestedSpecialty": "medical specialty needed",
      "symptoms_list": ["symptom1", "symptom2", "symptom3", "symptom4", "symptom5"]
    }`;

    // Note: I've slightly adjusted the prompt and JSON format to specifically ask for
    // symptoms in a list, as that's what your request implies for "Give me 5 symptoms".
    // If you strictly want the *original* format, the AI might just describe diabetes
    // without listing symptoms in a dedicated field.
    // I added "symptoms_list" to accommodate your specific request.

    console.log("Sending prompt to Gemini:", hardcodedPrompt); // Debugging: See what's sent

    const result = await model.generateContent(hardcodedPrompt); // Using the hardcoded prompt
    const response = result.response;
    const text = response.text();

    console.log("Raw response text from Gemini:", text); // Debugging: See raw response

    // Extract JSON from the response
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const jsonResponse = JSON.parse(jsonMatch[0]);
      console.log("Parsed JSON response from Gemini:", jsonResponse); // Debugging: See parsed JSON
      return jsonResponse; // Return the parsed JSON
    }

    throw new Error("Invalid response format from AI");
  } catch (error) {
    console.error("Gemini API Error:", error);

    // Fallback mock response if API fails
    return {
      diagnosis: "General Medical Consultation Needed",
      severity: "medium",
      description: "Please consult with a healthcare professional for proper diagnosis",
      advice: "Schedule an appointment with your doctor for evaluation",
      suggestedSpecialty: "General Practice",
      symptoms_list: [] // Add this to the fallback too, for consistency
    };
  }
};

// To test this, you'll need to call analyzeSymptoms somewhere in your App.js
// For example, in an useEffect or a button click.
// For now, it will simply run the hardcoded prompt when `analyzeSymptoms` is called.