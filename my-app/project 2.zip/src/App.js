import React, { useState, useEffect,useRef  } from 'react';
import './App.css';
import { analyzeSymptoms } from './utils/api';
import useSpeechRecognition from './hooks/useSpeechRecognition';
import "regenerator-runtime/runtime";

function App() {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [aiResponse, setAiResponse] = useState(null);
  const [hospitals, setHospitals] = useState([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [userLocation, setUserLocation] = useState(null);
  const latestTranscriptRef = useRef("");

  // Get user location
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => {
          console.error("Geolocation error:", error);
          setUserLocation({ lat: 40.7128, lng: -74.0060 });
        }
      );
    }
  }, []);

  const { startListening, stopListening } = useSpeechRecognition({
    onResult: (result) => {
      setTranscript(result);  
      latestTranscriptRef.current = result;  
    },
    onEnd: () => {
      setIsListening(false);
      const finalTranscript = latestTranscriptRef.current.trim();
      if (finalTranscript) {
        processSymptoms(finalTranscript);
      }
    }
  });

  const handleMicClick = () => {
    if (isListening) {
      stopListening();
      setIsListening(false);
    } else {
      setTranscript("");
      setIsListening(true);
      startListening();
    }
  };

  const processSymptoms = async (symptoms) => {
    if (!symptoms.trim()) return;

    setIsProcessing(true);
    try {
      const response = await analyzeSymptoms(symptoms);
      setAiResponse(response);

      if (response?.suggestedSpecialty) {
        findNearbyHospitals(response.suggestedSpecialty);
      }
    } catch (error) {
      console.error("Error processing symptoms:", error);
      alert("Error analyzing symptoms. Please try again.");
    }
    setIsProcessing(false);
  };

  const findNearbyHospitals = (specialty) => {
    if (!userLocation) return;

    const mockHospitals = [
      {
        id: 1, name: "City General Hospital", address: "123 Medical Center Drive",
        distance: "0.8 miles", specialty: "Emergency Medicine", rating: 4.5,
        waitTime: "15 min", coordinates: { lat: userLocation.lat + 0.01, lng: userLocation.lng + 0.01 }
      },
      {
        id: 2, name: "Unity Medical Center", address: "456 Health Avenue",
        distance: "1.2 miles", specialty: "General Practice", rating: 4.2,
        waitTime: "25 min", coordinates: { lat: userLocation.lat - 0.01, lng: userLocation.lng + 0.02 }
      },
      {
        id: 3, name: "Advanced Care Institute", address: "789 Wellness Boulevard",
        distance: "2.1 miles", specialty: "Orthopedics", rating: 4.7,
        waitTime: "10 min", coordinates: { lat: userLocation.lat + 0.02, lng: userLocation.lng - 0.01 }
      },
      {
        id: 4, name: "Mental Health Center", address: "321 Wellness Street",
        distance: "1.5 miles", specialty: "Psychiatry", rating: 4.6,
        waitTime: "20 min", coordinates: { lat: userLocation.lat + 0.015, lng: userLocation.lng - 0.015 }
      }
    ];

    const filtered = specialty !== "General Practice"
      ? mockHospitals.filter(h => h.specialty === specialty)
      : mockHospitals;

    setHospitals(filtered);
  };

  const getDirections = (hospital) => {
    if (!userLocation || !hospital.coordinates) return;
    const url = `https://www.google.com/maps/dir/?api=1&origin=${userLocation.lat},${userLocation.lng}&destination=${hospital.coordinates.lat},${hospital.coordinates.lng}&travelmode=driving`;
    window.open(url, '_blank');
  };

  return (
    <div className="health-assistant">
      <header className="app-header">
        <div className="app-title">
          <i className="fas fa-heartbeat"></i> Health Assistant
        </div>
        <div className="user-info">
          <i className="fas fa-map-marker-alt"></i>
          <span>{userLocation ? "Location enabled" : "Enable location"}</span>
        </div>
      </header>

      <div className="app-content">
        <div className="sidebar">
          <h3>How it works</h3>
          <ol style={{ marginLeft: 20, marginTop: 15, lineHeight: 1.8 }}>
            <li>Click the microphone button</li>
            <li>Describe your symptoms</li>
            <li>AI will analyze your condition</li>
            <li>Get personalized health advice</li>
            <li>Find the best hospitals nearby</li>
          </ol>
          <div style={{ marginTop: 30 }}>
            <h3>Try saying:</h3>
            <ul style={{ marginLeft: 20, marginTop: 10, lineHeight: 1.8 }}>
              <li>"I have a headache and fever"</li>
              <li>"My stomach hurts"</li>
              <li>"I have chest pain"</li>
              <li>"I feel anxious and overthink"</li>
            </ul>
          </div>
        </div>

        <div className="main-content">
          <div className="speech-section">
            <h2>Describe your symptoms</h2>
            <button
              className={`mic-button ${isListening ? 'listening' : ''}`}
              onClick={handleMicClick}
            >
              <i className="fas fa-microphone"></i>
            </button>
            <p>{isListening ? "Listening... Speak now" : "Click the microphone to start"}</p>
            <div className="transcript-box">
              {transcript || (isListening ? "Listening..." : "Your speech will appear here...")}
            </div>
          </div>

          {isProcessing && (
            <div style={{ textAlign: 'center', margin: '20px 0' }}>
              <i className="fas fa-spinner fa-spin" style={{ fontSize: 24, color: '#3498db' }}></i>
              <p>Analyzing your symptoms with AI...</p>
            </div>
          )}

          {aiResponse && (
            <div className="response-section">
              <h2>Health Assessment</h2>
              <div style={{ marginTop: 15 }}>
                <p><strong>Primary Diagnosis:</strong> {aiResponse.diagnosis}</p>
                <p>
                  <strong>Severity:</strong>{' '}
                  <span style={{ color:
                    aiResponse.severity === 'high' ? '#e74c3c' :
                    aiResponse.severity === 'medium' ? '#f39c12' : '#27ae60'
                  }}>
                    {aiResponse.severity}
                  </span>
                </p>
                <p><strong>Description:</strong> {aiResponse.description}</p>
                <p><strong>Advice:</strong> {aiResponse.advice}</p>

                {aiResponse.symptoms_list?.length > 0 && (
                  <div style={{ marginTop: 15 }}>
                    <p><strong>Related Symptoms:</strong></p>
                    <ul style={{ marginLeft: 20 }}>
                      {aiResponse.symptoms_list.map((s, i) => <li key={i}>{s}</li>)}
                    </ul>
                  </div>
                )}

                {aiResponse.allDiagnoses?.length > 1 && (
                  <div style={{ marginTop: 20 }}>
                    <p><strong>Other Possible Conditions:</strong></p>
                    {aiResponse.allDiagnoses.slice(1).map((d, i) => (
                      <div key={i} style={{ marginLeft: 20, marginBottom: 10 }}>
                        <p><em>{d.diagnosis}</em> (Likelihood: {d.likelihood})</p>
                        <p style={{ fontSize: '0.9em', color: '#666' }}>{d.notes}</p>
                      </div>
                    ))}
                  </div>
                )}

                {aiResponse.disclaimer && (
                  <div style={{
                    marginTop: 20, padding: 10,
                    backgroundColor: '#f8f9fa', borderLeft: '4px solid #007bff'
                  }}>
                    <p style={{ fontSize: '0.85em', color: '#666', margin: 0 }}>
                      <strong>Disclaimer:</strong> {aiResponse.disclaimer}
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {hospitals.length > 0 && (
            <div className="hospitals-section">
              <h2 className="section-title">Recommended Hospitals Nearby</h2>
              <p>Based on your symptoms, we recommend these facilities:</p>

              {hospitals.map(hospital => (
                <div key={hospital.id} className="hospital-card">
                  <div className="hospital-icon">
                    <i className="fas fa-hospital"></i>
                  </div>
                  <div className="hospital-info">
                    <div className="hospital-name">{hospital.name}</div>
                    <div className="hospital-address">{hospital.address}</div>
                    <div className="hospital-distance">
                      {hospital.distance} away • {hospital.specialty} • Wait time: {hospital.waitTime}
                    </div>
                  </div>
                  <button
                    className="action-button"
                    onClick={() => getDirections(hospital)}
                  >
                    Directions <i className="fas fa-directions"></i>
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;
